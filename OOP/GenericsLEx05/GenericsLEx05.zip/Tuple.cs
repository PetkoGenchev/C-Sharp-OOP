﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace GenericsLEx05
{
    public class Tuple<TFirst,TSecond>
    {
        public TFirst FirstItem { get; set; }
        public TSecond SecondItem { get; set; }

        public Tuple(TFirst firstItem, TSecond secondItem)
        {
            this.FirstItem = firstItem;
            this.SecondItem = secondItem;
        }

        public override string ToString()
        {
            return $"{FirstItem} -> {SecondItem}";
        }
    }
}
