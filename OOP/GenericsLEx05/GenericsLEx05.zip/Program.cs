﻿using System;
using System.Linq;

namespace GenericsLEx05
{
    class Program
    {
        static void Main(string[] args)
        {
            var firstInput = Console.ReadLine()
                .Split(' ',StringSplitOptions.RemoveEmptyEntries)
                .ToList();

            if (firstInput.Count > 2)
            {
               firstInput[0]  = $"{firstInput[0]} {firstInput[1]}";
                firstInput.RemoveAt(1); 
            }

            var tupleOne = new Tuple<string,string>(firstInput[0], firstInput[1]);

            var secondInput = Console.ReadLine().Split().ToArray();

            var tupleTwo = new Tuple<string, int>(secondInput[0], int.Parse(secondInput[1]));

            var thirdInput = Console.ReadLine().Split().ToArray();

            var tupleThree = new Tuple<int, double>(int.Parse(thirdInput[0]), double.Parse(thirdInput[1])); ;

            Console.WriteLine(tupleOne);
            Console.WriteLine(tupleTwo);
            Console.WriteLine(tupleThree);
        
        
        }
    }
}
