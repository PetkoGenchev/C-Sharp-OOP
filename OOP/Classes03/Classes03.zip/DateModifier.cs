﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;

namespace Classes03
{
    class DateModifier
    {
        static void Main(string[] args)
        {

            var input = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            var input2 = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            System.DateTime first = new System.DateTime(input[0], input[1], input[2]);
            System.DateTime second = new System.DateTime(input2[0], input2[1], input2[2]);

            System.TimeSpan result = first.Subtract(second);

            var resultingStuff = Math.Abs(result.TotalDays);

            Console.WriteLine(resultingStuff);


        }
    }
}